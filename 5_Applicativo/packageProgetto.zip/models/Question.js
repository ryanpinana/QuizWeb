const mongoose = require("mongoose")

const questionSchema = new mongoose.Schema({
    text: {type: String, required: true},
    options: [{type: String, required: true}],
    correctAnswers: [{type: Number, required: true}],
    type: {type: String, enum: ["single", "multiple"], default: "single"},
    difficulty: { type: String, enum: ["easy", "medium", "hard"], default: "medium" }
})

module.exports = mongoose.model("Questions", questionSchema)