const mongoose = require("mongoose")

const questionSchema = new mongoose.Schema({
    text: {type: String, required: true},
    options: [{type: String, required: true}],
    correctAnswers: [{type: Number, required: true}],
    type: {type: String, enum: ["single", "multiple"], default: "single"},
    difficulty: { type: String, enum: ["facile", "medai", "difficile"], default: "media" }
})

module.exports = mongoose.model("Questions", questionSchema)