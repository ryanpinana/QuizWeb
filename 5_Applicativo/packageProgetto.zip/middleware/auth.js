const User = require('../models/User')

// Middleware che rende disponibile l'utente loggato ai template
async function currentUserUser(req, res, next) {
  if (req.session && req.session.userId) {
    try {
      const user = await User.findById(req.session.userId);
      res.locals.currentUser = user
    } catch (err) {
      console.error("Errore nel recupero utente:", err);
      res.locals.currentUser = null
    }
  } else {
    res.locals.currentUser = null
  }
  next()
}

// Middleware che permette l'accesso solo all'amministratore
async function requireAuthAdmin(req, res, next) {
  console.log(req.session.userId)
  if (!req.session || !req.session.userId) {
    return res.redirect("/login")
  }

  try {
    const user = await User.findById(req.session.userId);
    if (!user || user.role !== "Admin") {
      return res.status(403).render("403", {
        title: "Accesso negato",
        msg: "Solo l'amministratore può accedere a questa sezione."
      });
    }
    next();
  } catch (err) {
    console.error("Errore autenticazione admin:", err)
    res.status(500).send("Errore interno del server")
  }
}

// Funzione per login
async function loginUser(req, res) {
  const { username, password } = req.body;

  try {
    const user = await User.findOne({ username, password })

    if (!user) {
      return res.render("login", {
        title: "Login Amministratore",
        error: "Credenziali non valide."
      });
    }

    console.log(user._id)
    req.session.userId = user._id
    console.log(req.session.userId)
    res.redirect("/admin")
  } catch (err) {
    console.error("Errore login:", err)
    res.status(500).send("Errore interno del server")
  }
}

// Logout
function logoutUser(req, res) {
  req.session = null
  res.redirect("/")
}

module.exports = {
  requireAuthAdmin,
  currentUserUser,
  loginUser,
  logoutUser
};
