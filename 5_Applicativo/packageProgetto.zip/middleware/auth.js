const users = require('../data/users');
/*
Se sei loggato, in tutti i template puoi scrivere {{currentUser.name}}, {{currentUser.username}}, ecc.
Se non sei loggato, currentUser vale null e i template possono mostrare i link “Login” al posto di “Profilo/Logout”.
*/
function currentUserUser(req, res, next) {
  res.locals.currentUser = (req.session && users.find(u => u.id === req.session.userId)) || null;
  next();
}

function requireAuth(req, res, next) {
  if (req.session && req.session.userId) {
    return res.redirect("/login");
  }
}

module.exports = { currentUserUser, requireAuth };
