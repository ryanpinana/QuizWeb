require('dotenv').config();
const path = require('path');
const express = require('express');
const morgan = require('morgan');
const cookieSession = require('cookie-session');
const hbs = require('hbs');
const mongoose = require("mongoose");

mongoose.connect(process.env.MONGO_URI, {useNewUrlParser: true, useUnifiedTopology: true})
.then(() => console.log("MongoDB connesso"))
.catch(err => console.error(err));

const { currentUserUser } = require('./middleware/auth');
const pagesRouter = require('./routes/pages');
const authRouter = require('./routes/auth');

const questionRoutes = require("./routes/questions");
const quizRoutes = require("./routes/quiz");

hbs.registerHelper(path.join(__dirname, "views/partials"));
hbs.registerHelper("eq", function (a, b){
  return a === b;
});

import adminRoutes from "./routes/admin.js"


const PORT = process.env.PORT || 3000;
const SESSION_KEYS = (process.env.SESSION_KEYS || 'dev1,dev2').split(',').map(s => s.trim());

const app = express();

app.use("/admin", adminRoutes)

//modulo che effettua logger in console per le richieste ricevute
app.use(morgan('dev'));
//utile per form POST
app.use(express.urlencoded({ extended: false }));
//asset statici
app.use(express.static(path.join(__dirname, 'public')));

app.use("/questions", questionRoutes);
app.use("/quiz", quizRoutes);

//template engine
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'hbs');
hbs.registerPartials(path.join(__dirname, 'views', 'partials'));

app.use(cookieSession({
  name: 'session',
  keys: SESSION_KEYS,
  maxAge: 24 * 60 * 60 * 1000
}));

//in tutto il template posso visionare le informazioni dell'utente loggato, se ci sono
app.use(currentUserUser);

//configuriamo che il nostro server ha queste Routes
app.use(pagesRouter);
app.use(authRouter);

app.use((req, res) => {
  res.status(404).render('404', { title: '404', msg: 'Pagina non trovata' });
});

app.listen(PORT, () => {
  console.log(`Server avviato su http://localhost:${PORT}`);
});
