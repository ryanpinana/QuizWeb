// Array di utenti simulato (nessun DB)
// ⚠️ In produzione non salvare password in chiaro
module.exports = [
  { id: 1, username: 'mario', password: 'password123', name: 'Mario Rossi', role: 'teacher' },
  { id: 2, username: 'luigi', password: 'secret456',  name: 'Luigi Bianchi', role: 'student' },
  { id: 3, username: 'anna',  password: 'qwerty',     name: 'Anna Verdi',   role: 'student' }
];
