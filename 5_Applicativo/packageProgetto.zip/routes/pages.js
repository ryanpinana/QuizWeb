const express = require('express');
const users = require('../data/users');
const { requireAuthAdmin } = require('../middleware/auth');

const router = express.Router();

router.get('/', (req, res) => {
  const { msg } = req.query;
  console.log(req.session.userId);
  res.render('home', { title: 'Home', msg });
});

router.get('/profile', requireAuthAdmin, (req, res) => {
  const me = users.find(u => u.id === req.session.userId);
  res.render('profile', { title: 'Profilo', me });
});

router.get('/users', requireAuthAdmin, (req, res) => {
  res.render('users', { title: 'Utenti', users });
});

module.exports = router;
