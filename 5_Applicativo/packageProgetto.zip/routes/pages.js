const express = require('express');

const router = express.Router();

router.get('/', (req, res) => {
  const { msg } = req.query;
  console.log(req.session.userId);
  res.render('home', { title: 'Home', msg });
});

module.exports = router;
