const express = require("express");
const Quiz = require("../models/Quiz.js")
const Question = require("../models/Question.js")
import { ensureAdmin } from "../middleware/auth.js";

const router = express.Router()

router.use(ensureAdmin)

router.get("/", async (req, res) => {
    try{
        const quizzes = await Quiz.find()
        const questions = await Question.find()

        res.render("admin/dashboard", {
            user: req.session.user,
            quizzes,
            questions
        })
    }catch(err){
        console.error("Errore caricamento admin dashboard:", err)
        res.status(500).send("Errore caricamento pannello admin")
    }
})

router.get("/questions/new", async(req, res) => {
    res.render("admin/question-form", {action: "create"})
})

router.post("/questions/new", async(req, res) => {
    try{
        const {text, option, correctAnswers, type} = req.body

        const question = new Question({
            text,
            options: options.split("|").map(o => o.trim()),
            correctAnswers: correctAnswers
            .split(",")
            .map(n => parseInt(n.trim()))
            .filter(n => !isNaN(n)),
            type
        })

        await question.save()
        res.redirect("/admin")
    }catch(err){
        console.error("Errore creazione domanda:", err)
        res.status(500).send("Errore nel salvataggio della domanda")
    }
})

router.get("/quizzes/new", async (req, res) => {
    try{
        const questions = await Question.find()
        res.render("admin/quiz-form", {action: "create", questions})
    }catch(err){
        console.error("Errore caricamento form:", err)
        res.status(500).send("Errore nel caricamento del form del quiz")
    }
})

router.post("/quizzes/new", async (req, res) => {
    try {
        const { title, description, questionIds } = req.body

        // Normalizza l’input per accettare anche un singolo valore
        const selectedQuestions = Array.isArray(questionIds)
        ? questionIds
        : questionIds
        ? [questionIds]
        : []

        const quiz = new Quiz({
        title,
        description,
        questions: selectedQuestions
        })

        await quiz.save()
        res.redirect("/admin")
    } catch (err) {
        console.error("Errore creazione quiz:", err)
        res.status(500).send("Errore nel salvataggio del quiz")
    }
})

export default router