const express = require("express")
const Quiz = require("../models/Quiz.js")
const Question = require("../models/Question.js")

const router = express.Router()



//DASHBOARD ADMIN
router.get("/", async (req, res) => {
  try {
    // Recupera tutti i quiz e domande senza usare populate
    const quizzes = await Quiz.find().lean();
    const questions = await Question.find().lean();

    // Renderizza la dashboard
    res.render("admin/dashboard", {
      title: "Dashboard Admin",
      quizzes,
      questions,
      user: { name: "Admin", role: "Admin" }
    });
  } catch (err) {
    console.error("Errore nel caricamento dashboard admin:", err);
    res.status(500).send("Errore nel caricamento della dashboard admin.");
  }
});

router.get("/questions/new", async(req, res) => {
    res.render("admin/question-form", {action: "create"})
})

router.post("/questions/new", async(req, res) => {
    try{
        const {text, option, correctAnswers, type} = req.body

        const question = new Question({
            text,
            options: option.split("|").map(o => o.trim()),
            correctAnswers: correctAnswers
            .split(",")
            .map(n => parseInt(n.trim()))
            .filter(n => !isNaN(n)),
            type
        })

        await question.save()
        res.redirect("/admin")
    }catch(err){
        console.error("Errore creazione domanda:", err)
        res.status(500).send("Errore nel salvataggio della domanda")
    }
})

router.get("/quizzes/new", async (req, res) => {
    try{
        const questions = await Question.find()
        res.render("admin/quiz-form", {action: "create", questions})
    }catch(err){
        console.error("Errore caricamento form:", err)
        res.status(500).send("Errore nel caricamento del form del quiz")
    }
})

router.post("/quizzes/new", async (req, res) => {
    try {
        const { title, description, questionIds } = req.body

        const selectedQuestions = Array.isArray(questionIds)
        ? questionIds
        : questionIds
        ? [questionIds]
        : []

        const quiz = new Quiz({
        title,
        description,
        questions: selectedQuestions
        })

        await quiz.save()
        res.redirect("/admin")
    } catch (err) {
        console.error("Errore creazione quiz:", err)
        res.status(500).send("Errore nel salvataggio del quiz")
    }
})

// Mostra il form di modifica
router.get("/questions/:id/edit", async (req, res) => {
  const question = await Question.findById(req.params.id).lean()
  if (!question){
    return res.status(404).send("Domanda non trovata")
  }
  res.render("admin/question-form", { question })
})

// Salva le modifiche
router.post("/questions/:id/edit", async (req, res) => {
  try {
    const { text, option, correctAnswers, type } = req.body

    const updated = {
      text,
      options: option ? option.split("|").map(o => o.trim()) : [],
      correctAnswers: correctAnswers
        ? correctAnswers.split(",").map(n => parseInt(n.trim())).filter(n => !isNaN(n))
        : [],
      type,
    }

    await Question.findByIdAndUpdate(req.params.id, updated)
    res.redirect("/admin")
  } catch (err) {
    console.error("Errore modifica domanda:", err)
    res.status(500).send("Errore durante la modifica della domanda")
  }
})

// Mostra il form di modifica
router.get("/quizzes/:id/edit", async (req, res) => {
  const quiz = await Quiz.findById(req.params.id).lean();
  const questions = await Question.find().lean();
  if (!quiz) return res.status(404).send("Quiz non trovato");
  res.render("admin/quiz-form", { quiz, questions });
});

// Salva le modifiche
router.post("/quizzes/:id/edit", async (req, res) => {
  try {
    const { title, description, questionIds } = req.body;
    const updated = {
      title,
      description,
      questions: Array.isArray(questionIds)
        ? questionIds
        : [questionIds],
    };
    await Quiz.findByIdAndUpdate(req.params.id, updated);
    res.redirect("/admin");
  } catch (err) {
    console.error("Errore modifica quiz:", err);
    res.status(500).send("Errore durante la modifica del quiz");
  }
});


module.exports = router;