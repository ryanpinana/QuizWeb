const express = require('express');
const { loginUser, logoutUser } = require('../middleware/auth');

const router = express.Router();

router.get("/login", async (req, res) => {
  res.render("login", {title: "Login Amministratore"});
})

// Logout
router.get("/logout", (req, res) => {
  req.session = null

  res.redirect("/")
});

router.post("/login", loginUser);
router.post("/logout", logoutUser);

module.exports = router;