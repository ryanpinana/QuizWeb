const express = require('express');
const users = require('../data/users');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

router.get('/login', (req, res) => {
  const { msg } = req.query;
  res.render('login', { title: 'Login', msg });
});

router.post('/login', (req, res) => {
  const { username, password } = req.body;
  const user = users.find(u => u.username === username && u.password === password);
  if (!user) {
    return res.status(401).render('login', { title: 'Login', errore: 'Credenziali non valide.' });
  }
  req.session.userId = user.id;
  req.session.username = user.username;
  res.redirect('/profile');
});

router.get('/logout', requireAuth, (req, res) => {
  res.render('home', { title: 'Logout', msg: 'Vuoi uscire? Premi il pulsante.' });
});

router.post('/logout', requireAuth, (req, res) => {
  req.session = null;
  res.redirect('/?msg=Logout%20effettuato');
});

module.exports = router;
