const express = require('express');
const { loginUser, logoutUser } = require('../middleware/auth');

const router = express.Router();

router.get("/login", async (req, res) => {
  res.render("login", {title: "Login Amministratore"});
})

router.post("/login", loginUser);
router.post("/logout", logoutUser);

module.exports = router;