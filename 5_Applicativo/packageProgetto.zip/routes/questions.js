const express = require("express")
const router = express.Router()
const Question = require("../models/Question")

//Lista tutte le domande
router.get("/", async (req, res) => {
    try{
        const questions = await Question.find()
        res.json(questions)
    }catch(err){
        res.status(500).json({error: err.message})
    }
})

//Lista in dettaglio una domanda
router.get("/:id", async (req, res) => {
    try{
        const question = await Question.findById(req.params.id)
        if(!question){
            return res.status(404).json({error: "Domanda non trovata"})
        }
        res.json(question)
    }catch(err){
        res.status(500).json({error: err.message})
    }
})

//Crea una nuova domanda
router.post("/", async (req, res) =>{
    try{
        const question = new Question(req.body())
        await question.save()
        res.status(201).json(question)
    }catch(err){
        res.status(400).json({error: err.message})
    }
})

//Aggiorna una domanda
router.put("/:id", async (req, res) => {
    try{
        const question = await Question.findByIdAndUpdate(
            req.params.id,
            req.body,
            {new: true, runValidators: true}
        )
        if(!question){
            return res.status(404).json({error: "Domanda non trovata"})
        }
        res.json(question)
    }catch(err){
        res.status(400).json({error: err.message})
    }
})

//Cancella una domanda
router.delete("/:id", async (req,res) => {
    try{
        const question = await Question.findByIdAndDelete(req.params.id)
        if(!question){
            return res.status(404).json({error: "Domanda non trovata"})
        }
        res.json({message: "Domanda eliminata con successo"})
    }catch(err){
        res.status(500).json({error: err.message})
    }
})

module.exports = router