const express = require("express")
const router = express.Router()
const Quiz = require("../models/Quiz")
const Question = require("../models/Question")

//Lista tutti i quiz con le domande
router.get("/", async (req, res) => {
    try{
        const quizzes = await Quiz.find()
        console.log(quizzes)
        res.render("quiz-list", {quizzes})
    }catch(err){
        res.status(500).json({error: err.message})
    }
})

//Prende in dettaglio un quiz
router.get("/:id", async (req, res) => {
    try{
        console.log(req.params.id)
        const quiz = await Quiz.findById(req.params.id)
        console.log(quiz)

        const questions = await Question.find({
            _id: {$in: quiz.questions}
        })

        console.log(questions)
        if(!quiz){
            return res.status(404).json({error: "Quiz non trovato"})
        }
        res.render("quiz-detail", {quiz, questions})
    }catch(err){
        res.status(500).json({error: err.message})
    }
})

//invia le risposte dell'utente e controlla i risultati
router.post("/:id/submit", async (req, res) => {
    try {
        const quiz = await Quiz.findById(req.params.id)
        const questions = await Question.find({ _id: { $in: quiz.questions } })

        let correct = 0
        let partial = 0
        let wrong = 0

        // Funzione per normalizzare qualsiasi tipo di input dal form (grazie a ChatGPT)
        function normalizeAnswer(answer) {
            if (answer === undefined || answer === null) return [];
            if (Array.isArray(answer)) {
                return answer
                .map(a => Number(a))
                .filter(n => Number.isFinite(n))
            }
            if (typeof answer === "string") {
                const s = answer.trim()
                if (s === "") return []
                if (s.includes(",")) {
                return s
                    .split(",")
                    .map(x => Number(x.trim()))
                    .filter(n => Number.isFinite(n))
                }
            const n = Number(s)
            return Number.isFinite(n) ? [n] : []
            }
            if (typeof answer === "number") return [answer]
                return []
        }

        questions.forEach((question, i) => {
            const rawAnswer = req.body[`q${i}`]
            const userAnswers = normalizeAnswer(rawAnswer)
            const correctAnswers = question.correctAnswers.map(Number)

            // Rimuovi duplicati e ordina (Parte riuscita grazie a chatGPT)
            const uniqUser = [...new Set(userAnswers)].sort((a, b) => a - b)
            const uniqCorrect = [...new Set(correctAnswers)].sort((a, b) => a - b)

            console.log(`\n[DEBUG] Domanda ${i + 1}: ${question.text}`)
            console.log("Risposte corrette:", uniqCorrect)
            console.log("Risposte utente:", uniqUser)

            if (uniqUser.length === 0) {
                console.log("→ Nessuna risposta → sbagliata ❌")
                wrong++
                return
            }

            // Esatto match (Risposta esatta)
            const isExactMatch =
                uniqUser.length === uniqCorrect.length &&
                uniqUser.every((val, idx) => val === uniqCorrect[idx])

            // Parziale: almeno una giusta ma non tutte
            const isPartial =
                uniqUser.some(a => uniqCorrect.includes(a)) && !isExactMatch

            if (isExactMatch) {
                console.log("→ Tutte giuste ✅")
                correct++
            } else if (isPartial) {
                console.log("→ Parzialmente giusta ⚠️")
                partial++
            } else {
                console.log("→ Tutte sbagliate ❌")
                wrong++
            }
        });

        // Calcolo punteggio
        const total = questions.length
        const score = ((correct + partial * 0.5) / total) * 100

        res.render("quiz-result", {
            quiz,
            total,
            correct,
            partial,
            wrong,
            score: Math.round(score)
        })
    } catch (err) {
        console.error("Errore nella verifica del quiz:", err)
        res.status(500).send("Errore nella verifica del quiz")
    }
});


//crea un nuovo quiz, il body JSON deve essere: { title, description, category, questions: [idDomanda1, idDomanda2...] }
router.post("/", async (req, res) => {
    try{
        const quiz = new Quiz(req.body)
        await quiz.save()
        res.status(201).json(quiz)
    } catch(err){
        res.status(400).json({error: err.message})
    }
})

//Modifica un quiz
router.post("/:id", async (req, res) => {
    try{
        const quiz = await Quiz.findByIdAndUpdate(
            req.params.id,
            req.body,
            {new: true, runValidators: true}
        ).populate("questions")
        if(!quiz){
            return res.status(404).json({error: "Quiz non trovato"})
        }
        res.json(quiz)
    }catch(err){
        res.status(400).json({error: err.message})
    }
})

//Elimina quiz
router.delete("/:id", async (req, res) => {
    try{
        const quiz = await Quiz.findByIdAndDelete(req.params.id)
        if(!quiz){
            return res.status(404).json({error: "Quiz non trovato"})
        }
        res.json({message: "Quiz eliminato con successo"})
    }catch(err){
        res.status(500).json({error: err.message})
    }
})

module.exports = router