const express = require("express")
const router = express.Router()
const Quiz = require("../models/Quiz")

//Lista tutti i quiz con le domande
router.get("/", async (req, res) => {
    try{
        const quizzes = await Quiz.find()
        console.log(quizzes)
        res.render("quiz-list", {quizzes})
    }catch(err){
        res.status(500).json({error: err.message})
    }
})

//Prende in dettaglio un quiz
router.get("/:id", async (req, res) => {
    try{
        console.log(req.params.id)
        const quiz = await Quiz.findById(req.params.id)
        console.log(quiz)
        if(!quiz){
            return res.status(404).json({error: "Quiz non trovato"})
        }
        res.render("quiz-detail", {quiz})
    }catch(err){
        res.status(500).json({error: err.message})
    }
})

//crea un nuovo quiz, il body JSON deve essere: { title, description, category, questions: [idDomanda1, idDomanda2...] }
router.post("/", async (req, res) => {
    try{
        const quiz = new Quiz(req.body)
        await quiz.save()
        res.status(201).json(quiz)
    } catch(err){
        res.status(400).json({error: err.message})
    }
})

//Modifica un quiz
router.post("/:id", async (req, res) => {
    try{
        const quiz = await Quiz.findByIdAndUpdate(
            req.params.id,
            req.body,
            {new: true, runValidators: true}
        ).populate("questions")
        if(!quiz){
            return res.status(404).json({error: "Quiz non trovato"})
        }
        res.json(quiz)
    }catch(err){
        res.status(400).json({error: err.message})
    }
})

router.delete("/:id", async (req, res) => {
    try{
        const quiz = await Quiz.findByIdAndDelete(req.params.id)
        if(!quiz){
            return res.status(404).json({error: "Quiz non trovato"})
        }
        res.json({message: "Quiz eliminato con successo"})
    }catch(err){
        res.status(500).json({error: err.message})
    }
})

module.exports = router