const express = require("express")
const router = express.Router()
const Quiz = require("../models/Quiz")

router.get("/", async (req, res) => {
    const quizzes = await Quiz.find().populate("questions")
    res.json(quizzes)
})

router.post("/", async (req, res) => {
    try{
        const quiz = new Quiz(req.body)
        await quiz.save()
        res.status(201).json(quiz)
    } catch(err){
        res.status(400).json({error: err.message})
    }
})

module.exports = router